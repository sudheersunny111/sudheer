from django.http import HttpResponse
def welcome(request):
    return HttpResponse("<html><body bgcolor=pink><h1><center>WELCOME TO LOKESH IT</h1></body></center></html>")
